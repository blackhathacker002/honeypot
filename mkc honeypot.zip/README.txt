Conversation opened. 3 messages. All messages read.

Skip to content
Using Echelon Institute of Technology Mail with screen readers
Enable desktop notifications for Echelon Institute of Technology Mail.
   OK  No thanks

1 of 612
Document from unknown
External
Inbox

24-CSE-CS-017 MIHIR
Attachments
Nov 11, 2025, 3:16 PM (17 hours ago)
 

SHASHIKANT
Attachments
1:53 AM (7 hours ago)
to me



On Tue, 11 Nov 2025 at 15:16, 24-CSE-CS-017 MIHIR <24-cse-cs-017mihir@eitfaridabad.co.in> wrote:

 8 Attachments
  •  Scanned by Gmail

SHASHIKANT
Attachments
1:55 AM (7 hours ago)
to me

 One attachment
  •  Scanned by Gmail
HONEYPOT AMAZON TRAP - INSTRUCTIONS

1. Create folder: honeypot-amazon-trap
2. Save all 6 files above in it:
   - index.html
   - dashboard.html
   - admin_login.html
   - admin_dashboard.html
   - styles.css
   - script.js

3. Open index.html in Chrome/Firefox

4. TEST:
   → Login with any email
   → Click any "Add to Cart" 7 times fast → TRAPPED!
   → Admin: Click "Admin Panel" → mihir@gmail.com / 1234
   → See trapped users

Images load from internet (picsum.photos) → visible on live server

NO BACKEND NEEDED. Works offline after first load.
README.txt
Displaying README.txt.