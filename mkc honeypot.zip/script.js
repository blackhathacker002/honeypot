if (window.location.pathname.includes("dashboard.html")) {
  const BAN_DURATION = 120000;     // 2 minutes
  const CLICK_THRESHOLD = 3;       // ← NOW 3 CLICKS = BAN
  let clickCount = 0;
  let lastClickTime = 0;
  let timeoutId = null;
  let countdownTimer = null;

  function showSuspendedScreen(remainingMs) {
    const overlay = document.getElementById("suspendedOverlay");
    const countdownEl = overlay.querySelector(".countdown");
    if (!overlay || !countdownEl) return;

    overlay.classList.remove("hidden");
    document.body.style.pointerEvents = "none";
    document.body.style.userSelect = "none";

    let seconds = Math.ceil(remainingMs / 1000);
    if (countdownTimer) clearInterval(countdownTimer);

    countdownTimer = setInterval(() => {
      seconds--;
      const m = Math.floor(seconds / 60);
      const s = seconds % 60;
      countdownEl.textContent = `${m}:${s.toString().padStart(2, "0")}`;
      if (seconds <= 0) {
        clearInterval(countdownTimer);
        overlay.classList.add("hidden");
        document.body.style.pointerEvents = "auto";
        document.body.style.userSelect = "auto";
        localStorage.removeItem("suspendedUntil");
      }
    }, 1000);
  }

  function checkBan() {
    const until = localStorage.getItem("suspendedUntil");
    if (!until) return;
    const time = Number(until);
    if (isNaN(time)) { localStorage.removeItem("suspendedUntil"); return; }
    const now = Date.now();
    if (now < time) showSuspendedScreen(time - now);
    else localStorage.removeItem("suspendedUntil");
  }

  function triggerBan() {
    const email = localStorage.getItem("currentUser") || "unknown@user.com";
    const time = new Date().toISOString();
    let users = JSON.parse(localStorage.getItem("suspiciousUsers") || "[]");
    users.push({ email, time });
    localStorage.setItem("suspiciousUsers", JSON.stringify(users));

    const until = Date.now() + BAN_DURATION;
    localStorage.setItem("suspendedUntil", until);
    showSuspendedScreen(BAN_DURATION);
  }

  function setupTrap() {
    document.querySelectorAll(".add-to-cart").forEach(btn => {
      btn.addEventListener("click", () => {
        const now = Date.now();

        // Reset if gap > 1 sec
        if (now - lastClickTime > 1000) {
          clickCount = 1;
        } else {
          clickCount++;
        }
        lastClickTime = now;

        if (timeoutId) clearTimeout(timeoutId);

        timeoutId = setTimeout(() => {
          if (clickCount >= CLICK_THRESHOLD) {
            triggerBan();  // ← BAN AFTER 3 CLICKS
          }
          clickCount = 0;
        }, 1000);
      });
    });
  }

  window.addEventListener("load", () => {
    checkBan();
    const until = localStorage.getItem("suspendedUntil");
    if (!until || Date.now() >= Number(until)) {
      setupTrap();
    }
  });

  window.addEventListener("beforeunload", () => {
    if (countdownTimer) clearInterval(countdownTimer);
    if (timeoutId) clearTimeout(timeoutId);
  });
}
// === SQL INJECTION TRAP ===
function saveSQLi(payload) {
  const ip = "BOT_IP_" + Math.random().toString(36).substr(2,5); // Fake IP
  const email = localStorage.getItem("currentUser") || "guest";
  const time = new Date().toISOString();

  let attacks = JSON.parse(localStorage.getItem("sqliAttacks") || "[]");
  attacks.push({ ip, email, payload, time });
  localStorage.setItem("sqliAttacks", JSON.stringify(attacks));
}

function checkSQLi(e) {
  const input = e.target.value.toLowerCase();
  const dangerous = [
    "'", '"', "--", ";", "union", "select", "drop", "insert", "update", "delete", 
    "1=1", "or 1", "admin", "password", "sleep(", "benchmark("
  ];

  for (let word of dangerous) {
    if (input.includes(word)) {
      saveSQLi(e.target.value);
      e.target.value = "Invalid search"; // Fake block
      setTimeout(triggerBan, 500); // Instant ban
      break;
    }
  }
}

function triggerSQLi() {
  const input = document.getElementById("sqliTrap").value;
  if (input.trim()) {
    saveSQLi(input);
    if (/['";]/.test(input)) {
      setTimeout(triggerBan, 300);
    }
  }
}